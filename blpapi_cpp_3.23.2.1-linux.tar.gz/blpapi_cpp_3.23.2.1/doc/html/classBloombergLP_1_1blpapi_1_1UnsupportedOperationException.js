var classBloombergLP_1_1blpapi_1_1UnsupportedOperationException =
[
    [ "UnsupportedOperationException", "classBloombergLP_1_1blpapi_1_1UnsupportedOperationException.html#aac0615d8a37144e1cd7a2cde9ea3e96a", null ],
    [ "description", "classBloombergLP_1_1blpapi_1_1UnsupportedOperationException.html#aa96fc91e0a878caf38caa30ca4bc54ec", null ],
    [ "what", "classBloombergLP_1_1blpapi_1_1UnsupportedOperationException.html#a8d4b96162e93e11e5816d83702578af8", null ]
];