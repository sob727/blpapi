var blpapi__versioninfo_8h =
[
    [ "blpapi_getVersionIdentifier", "blpapi__versioninfo_8h.html#ad502f3708a6b84a7148b080d66371cc7", null ],
    [ "blpapi_getVersionInfo", "blpapi__versioninfo_8h.html#a70fbb8117bfbd798a04ccc845a2d140a", null ],
    [ "operator<<", "blpapi__versioninfo_8h.html#a91001376b7dad3e27f12cba5cfe01df2", null ]
];