var blpapi__identity_8h =
[
    [ "blpapi_Identity_addRef", "blpapi__identity_8h.html#ae2e00310bb4e0d09ccd092c0188b4a3b", null ],
    [ "blpapi_Identity_getSeatType", "blpapi__identity_8h.html#ae929c7fa42252131419dc8f7e98adb45", null ],
    [ "blpapi_Identity_hasEntitlements", "blpapi__identity_8h.html#a00e4e048938539445968fc90372fba06", null ],
    [ "blpapi_Identity_isAuthorized", "blpapi__identity_8h.html#a419796c6f66ef552285a847de6c11d00", null ],
    [ "blpapi_Identity_release", "blpapi__identity_8h.html#a9bc121b0039a0c358aef231acf83c4e7", null ]
];