var searchData=
[
  ['hours',['HOURS',['../structBloombergLP_1_1blpapi_1_1DatetimeParts.html#a896c037a32087c5c20d97e64a1786880a4071f24c62fa1c9c6c34b8d2dd0f2b4e',1,'BloombergLP::blpapi::DatetimeParts']]]
];
