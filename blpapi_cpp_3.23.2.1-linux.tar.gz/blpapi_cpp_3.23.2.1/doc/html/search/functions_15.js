var searchData=
[
  ['year',['year',['../classBloombergLP_1_1blpapi_1_1Datetime.html#aa5d6d6d577c6d2ba3409c98cbd7079c5',1,'BloombergLP::blpapi::Datetime']]]
];
