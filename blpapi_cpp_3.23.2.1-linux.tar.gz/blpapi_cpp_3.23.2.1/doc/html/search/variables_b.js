var searchData=
[
  ['year',['year',['../group__blpapi__datetime.html#ga49090c3e2e08d23d7e954f5128f3a7bf',1,'blpapi_Datetime_tag']]]
];
