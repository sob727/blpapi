var searchData=
[
  ['pointer',['pointer',['../classBloombergLP_1_1blpapi_1_1Event_1_1iterator.html#acdf54f4fe65e239998093a170de34cc2',1,'BloombergLP::blpapi::Event::iterator::pointer()'],['../classBloombergLP_1_1blpapi_1_1Bytes.html#ac83ef8016f29fde25d7779924318c35e',1,'BloombergLP::blpapi::Bytes::pointer()']]]
];
