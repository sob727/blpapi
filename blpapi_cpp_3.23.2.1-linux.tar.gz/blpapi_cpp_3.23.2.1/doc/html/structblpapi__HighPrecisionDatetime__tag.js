var structblpapi__HighPrecisionDatetime__tag =
[
    [ "datetime", "group__blpapi__datetime.html#ga842aaa2a1f93c5ee077497111acb8e98", null ],
    [ "picoseconds", "group__blpapi__datetime.html#gabd2b7a50662c8fea660ae535431d2ada", null ]
];