var group__blpapi__streamproxy =
[
    [ "BloombergLP", "namespaceBloombergLP.html", null ],
    [ "blpapi", "namespaceBloombergLP_1_1blpapi.html", null ],
    [ "StreamProxyOstream", "structBloombergLP_1_1blpapi_1_1StreamProxyOstream.html", [
      [ "writeToStream", "structBloombergLP_1_1blpapi_1_1StreamProxyOstream.html#a5872abcd0c4e9b833f9e493f1a71e4df", null ]
    ] ],
    [ "OstreamWriter", "group__blpapi__streamproxy.html#gabd1a85d943fec3b3aab1f101aaaf2f69", null ]
];