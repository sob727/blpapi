var classBloombergLP_1_1blpapi_1_1VersionInfo =
[
    [ "VersionInfo", "classBloombergLP_1_1blpapi_1_1VersionInfo.html#a96cc203f92ffccbd05fec612b1e6b0c7", null ],
    [ "buildVersion", "classBloombergLP_1_1blpapi_1_1VersionInfo.html#a709c7837ef3e2e04ce5b500945dffb0d", null ],
    [ "headerVersion", "classBloombergLP_1_1blpapi_1_1VersionInfo.html#a224c6e68f7b1c928d79048c410b6de46", null ],
    [ "majorVersion", "classBloombergLP_1_1blpapi_1_1VersionInfo.html#a8c8341ffacc42ca313248a52e27ea4cf", null ],
    [ "minorVersion", "classBloombergLP_1_1blpapi_1_1VersionInfo.html#a4d04571319e8a3efc694fe5b607dab81", null ],
    [ "patchVersion", "classBloombergLP_1_1blpapi_1_1VersionInfo.html#a3d5e489a5d9e322f02d9d173d5e7d4be", null ],
    [ "runtimeVersion", "classBloombergLP_1_1blpapi_1_1VersionInfo.html#a8f47782c5897b1da8e9d96064e51bd97", null ],
    [ "versionIdentifier", "classBloombergLP_1_1blpapi_1_1VersionInfo.html#a06abac57961c80174cac185a6eeac9de", null ]
];