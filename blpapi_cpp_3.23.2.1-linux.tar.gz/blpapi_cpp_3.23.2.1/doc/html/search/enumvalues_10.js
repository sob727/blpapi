var searchData=
[
  ['year',['YEAR',['../structBloombergLP_1_1blpapi_1_1DatetimeParts.html#a896c037a32087c5c20d97e64a1786880ad327b6aedde7e5aa6a122dd9e2154f45',1,'BloombergLP::blpapi::DatetimeParts']]]
];
