var searchData=
[
  ['offset',['OFFSET',['../structBloombergLP_1_1blpapi_1_1DatetimeParts.html#a896c037a32087c5c20d97e64a1786880a9980a65495c97b765c5b7e2d62d82958',1,'BloombergLP::blpapi::DatetimeParts']]]
];
