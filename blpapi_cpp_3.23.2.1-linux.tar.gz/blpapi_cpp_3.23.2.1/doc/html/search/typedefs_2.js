var searchData=
[
  ['difference_5ftype',['difference_type',['../classBloombergLP_1_1blpapi_1_1Event_1_1iterator.html#ace405568d0b2f3fad4990044252c7732',1,'BloombergLP::blpapi::Event::iterator::difference_type()'],['../classBloombergLP_1_1blpapi_1_1Bytes.html#ad319fc54a93a2c7058c70e40428ed2e2',1,'BloombergLP::blpapi::Bytes::difference_type()']]]
];
