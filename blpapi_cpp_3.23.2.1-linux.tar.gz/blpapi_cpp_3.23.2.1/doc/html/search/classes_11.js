var searchData=
[
  ['versioninfo',['VersionInfo',['../classBloombergLP_1_1blpapi_1_1VersionInfo.html',1,'BloombergLP::blpapi']]]
];
