var structBloombergLP_1_1blpapi_1_1Message_1_1RecapType =
[
    [ "Type", "structBloombergLP_1_1blpapi_1_1Message_1_1RecapType.html#a1d1cfd8ffb84e947f82999c682b666a7", [
      [ "e_none", "structBloombergLP_1_1blpapi_1_1Message_1_1RecapType.html#a1d1cfd8ffb84e947f82999c682b666a7a8d06326d59b16c75d612ff828028264a", null ],
      [ "e_solicited", "structBloombergLP_1_1blpapi_1_1Message_1_1RecapType.html#a1d1cfd8ffb84e947f82999c682b666a7a8ac204a4fee84684dda25e6a7b08f6ce", null ],
      [ "e_unsolicited", "structBloombergLP_1_1blpapi_1_1Message_1_1RecapType.html#a1d1cfd8ffb84e947f82999c682b666a7a768b5bc38337c17ff8e1d4865de4f134", null ]
    ] ]
];