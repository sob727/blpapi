var searchData=
[
  ['blpapi_5feventhandleradapter',['blpapi_eventHandlerAdapter',['../classBloombergLP_1_1blpapi_1_1Session.html#a931ba54e37e62f7ee1f6eb96ad62b020',1,'BloombergLP::blpapi::Session']]],
  ['blpapi_5fprovidereventhandleradapter',['blpapi_providerEventHandlerAdapter',['../classBloombergLP_1_1blpapi_1_1ProviderSession.html#a9a165d0f0c4d0b98d1b5c9f931bc268e',1,'BloombergLP::blpapi::ProviderSession']]]
];
