var searchData=
[
  ['code',['code',['../structBloombergLP_1_1blpapi_1_1SubscriptionPreprocessError.html#a45a5b7c00a796a23f01673cef1dbe0a9',1,'BloombergLP::blpapi::SubscriptionPreprocessError']]],
  ['correlationid',['correlationId',['../structBloombergLP_1_1blpapi_1_1SubscriptionPreprocessError.html#a1cd4783478a9fb2b35770541e4a4378e',1,'BloombergLP::blpapi::SubscriptionPreprocessError']]]
];
