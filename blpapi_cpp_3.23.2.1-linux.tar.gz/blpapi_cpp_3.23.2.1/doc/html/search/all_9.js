var searchData=
[
  ['keepaliveenabled',['keepAliveEnabled',['../classBloombergLP_1_1blpapi_1_1SessionOptions.html#a5ce2d3b83358a39ebe59a35b75439202',1,'BloombergLP::blpapi::SessionOptions']]]
];
