var searchData=
[
  ['unknownerrorexception',['UnknownErrorException',['../classBloombergLP_1_1blpapi_1_1UnknownErrorException.html',1,'BloombergLP::blpapi']]],
  ['unsupportedoperationexception',['UnsupportedOperationException',['../classBloombergLP_1_1blpapi_1_1UnsupportedOperationException.html',1,'BloombergLP::blpapi']]]
];
