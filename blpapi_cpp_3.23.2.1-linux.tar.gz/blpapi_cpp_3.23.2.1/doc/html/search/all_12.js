var searchData=
[
  ['uchar',['UChar',['../namespaceBloombergLP_1_1blpapi.html#aed3b94a9657377dfa9c19807c7035ba7',1,'BloombergLP::blpapi']]],
  ['uint16',['UInt16',['../namespaceBloombergLP_1_1blpapi.html#a7fb9b972910b4774e709442f63baf975',1,'BloombergLP::blpapi']]],
  ['uint32',['UInt32',['../namespaceBloombergLP_1_1blpapi.html#a242cffcb866ce65ba05074227ddbfcf5',1,'BloombergLP::blpapi']]],
  ['uint64',['UInt64',['../namespaceBloombergLP_1_1blpapi.html#a7c804c133c4f8331fbbff4f3c95f89a0',1,'BloombergLP::blpapi']]],
  ['unbounded',['UNBOUNDED',['../classBloombergLP_1_1blpapi_1_1SchemaElementDefinition.html#adf764cbdea00d65edcd07bb9953ad2b7a6c65123d1b5b01632a477661055b01ef',1,'BloombergLP::blpapi::SchemaElementDefinition']]],
  ['unknown',['UNKNOWN',['../classBloombergLP_1_1blpapi_1_1Event.html#a2628ea8d12e8b2563c32f05dc7fff6faa6ce26a62afab55d7606ad4e92428b30c',1,'BloombergLP::blpapi::Event']]],
  ['unknownerrorexception',['UnknownErrorException',['../classBloombergLP_1_1blpapi_1_1UnknownErrorException.html',1,'UnknownErrorException'],['../classBloombergLP_1_1blpapi_1_1UnknownErrorException.html#a5d13a2712dc9ff3a925ecab55fb2ea0c',1,'BloombergLP::blpapi::UnknownErrorException::UnknownErrorException()']]],
  ['unresolved',['UNRESOLVED',['../classBloombergLP_1_1blpapi_1_1ResolutionList.html#a67a0db04d321a74b7e7fcfd3f1a3f70badd34e323cbfc10e56499d492dd2c3a66',1,'BloombergLP::blpapi::ResolutionList']]],
  ['unset_5fvalue',['UNSET_VALUE',['../classBloombergLP_1_1blpapi_1_1CorrelationId.html#ad9971b6ef33e02ba2c75d19c1d2518a1a8ce57869ee04cf783d86b39154e670be',1,'BloombergLP::blpapi::CorrelationId']]],
  ['unsubscribe',['unsubscribe',['../classBloombergLP_1_1blpapi_1_1Session.html#aecdefa1dd19165fb004163637383da98',1,'BloombergLP::blpapi::Session']]],
  ['unsubscribed',['UNSUBSCRIBED',['../classBloombergLP_1_1blpapi_1_1Session.html#a141815705f02d1c10701317803aa6031a74a51cb85a77f7a1752500134658ebd3',1,'BloombergLP::blpapi::Session']]],
  ['unsupportedoperationexception',['UnsupportedOperationException',['../classBloombergLP_1_1blpapi_1_1UnsupportedOperationException.html',1,'UnsupportedOperationException'],['../classBloombergLP_1_1blpapi_1_1UnsupportedOperationException.html#aac0615d8a37144e1cd7a2cde9ea3e96a',1,'BloombergLP::blpapi::UnsupportedOperationException::UnsupportedOperationException()']]],
  ['userdata',['userData',['../classBloombergLP_1_1blpapi_1_1Constant.html#a70bb0eb5ae5e355d4c98140096363511',1,'BloombergLP::blpapi::Constant::userData()'],['../classBloombergLP_1_1blpapi_1_1ConstantList.html#a70bb0eb5ae5e355d4c98140096363511',1,'BloombergLP::blpapi::ConstantList::userData()'],['../classBloombergLP_1_1blpapi_1_1SchemaElementDefinition.html#a70bb0eb5ae5e355d4c98140096363511',1,'BloombergLP::blpapi::SchemaElementDefinition::userData()'],['../classBloombergLP_1_1blpapi_1_1SchemaTypeDefinition.html#a70bb0eb5ae5e355d4c98140096363511',1,'BloombergLP::blpapi::SchemaTypeDefinition::userData()']]],
  ['userhandle',['UserHandle',['../group__blpapi__abstractsession.html#gab0af778a80bd31ca7506f14e92c5a1bd',1,'BloombergLP::blpapi']]]
];
