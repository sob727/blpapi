var searchData=
[
  ['recaptype',['RecapType',['../structBloombergLP_1_1blpapi_1_1Message_1_1RecapType.html',1,'BloombergLP::blpapi::Message']]],
  ['request',['Request',['../classBloombergLP_1_1blpapi_1_1Request.html',1,'BloombergLP::blpapi']]],
  ['requestref',['RequestRef',['../classBloombergLP_1_1blpapi_1_1RequestRef.html',1,'BloombergLP::blpapi']]],
  ['requesttemplate',['RequestTemplate',['../classBloombergLP_1_1blpapi_1_1RequestTemplate.html',1,'BloombergLP::blpapi']]],
  ['resolutionlist',['ResolutionList',['../classBloombergLP_1_1blpapi_1_1ResolutionList.html',1,'BloombergLP::blpapi']]]
];
