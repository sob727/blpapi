var structblpapi__TimePoint =
[
    [ "d_value", "group__blpapi__timepoint.html#gafa181ec9f620d9622899923654d37584", null ]
];