var searchData=
[
  ['seattype',['SeatType',['../classBloombergLP_1_1blpapi_1_1Identity.html#a476531b8b779ebb4a8672ef5b44a4de2',1,'BloombergLP::blpapi::Identity']]],
  ['serviceregistrationpriority',['ServiceRegistrationPriority',['../classBloombergLP_1_1blpapi_1_1ServiceRegistrationOptions.html#af5781c7c4efa7e01a90111113e115f52',1,'BloombergLP::blpapi::ServiceRegistrationOptions']]],
  ['status',['Status',['../classBloombergLP_1_1blpapi_1_1ResolutionList.html#a67a0db04d321a74b7e7fcfd3f1a3f70b',1,'BloombergLP::blpapi::ResolutionList::Status()'],['../classBloombergLP_1_1blpapi_1_1TopicList.html#a67a0db04d321a74b7e7fcfd3f1a3f70b',1,'BloombergLP::blpapi::TopicList::Status()']]],
  ['subscriptionstatus',['SubscriptionStatus',['../classBloombergLP_1_1blpapi_1_1Session.html#a141815705f02d1c10701317803aa6031',1,'BloombergLP::blpapi::Session']]]
];
