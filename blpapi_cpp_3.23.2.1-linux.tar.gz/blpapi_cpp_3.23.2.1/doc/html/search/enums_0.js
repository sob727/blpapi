var searchData=
[
  ['blpapi_5fdatatype_5ft',['blpapi_DataType_t',['../group__blpapi__types.html#gae51aef6b8fe12b4657827355e5a99531',1,'blpapi_types.h']]],
  ['blpapi_5flogging_5fseverity_5ft',['blpapi_Logging_Severity_t',['../group__blpapi__types.html#ga21857c3e93a96a514181197cf7e70929',1,'blpapi_types.h']]]
];
