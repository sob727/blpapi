var blpapi__logging_8h =
[
    [ "Severity", "structBloombergLP_1_1blpapi_1_1Logging_1_1Severity.html", "structBloombergLP_1_1blpapi_1_1Logging_1_1Severity" ],
    [ "blpapi_Logging_Func_t", "blpapi__logging_8h.html#afd241aaef739d851bda1f38bd4570bca", null ],
    [ "blpapi_Logging_logTestMessage", "blpapi__logging_8h.html#af1c4e7510d2a30225009d266edc83029", null ],
    [ "blpapi_Logging_registerCallback", "blpapi__logging_8h.html#a6a97e3070199a6323a963d5bf660bb2f", null ]
];