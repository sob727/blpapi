var annotated_dup =
[
    [ "BloombergLP", "namespaceBloombergLP.html", "namespaceBloombergLP" ],
    [ "blpapi_Datetime_tag", "structblpapi__Datetime__tag.html", "structblpapi__Datetime__tag" ],
    [ "blpapi_ErrorInfo", "structblpapi__ErrorInfo.html", "structblpapi__ErrorInfo" ],
    [ "blpapi_HighPrecisionDatetime_tag", "structblpapi__HighPrecisionDatetime__tag.html", "structblpapi__HighPrecisionDatetime__tag" ],
    [ "blpapi_TimePoint", "structblpapi__TimePoint.html", "structblpapi__TimePoint" ]
];