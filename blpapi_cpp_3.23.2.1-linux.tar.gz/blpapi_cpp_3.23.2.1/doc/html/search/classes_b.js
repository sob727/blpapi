var searchData=
[
  ['offset',['Offset',['../structBloombergLP_1_1blpapi_1_1Datetime_1_1Offset.html',1,'BloombergLP::blpapi::Datetime']]],
  ['operation',['Operation',['../classBloombergLP_1_1blpapi_1_1Operation.html',1,'BloombergLP::blpapi']]]
];
