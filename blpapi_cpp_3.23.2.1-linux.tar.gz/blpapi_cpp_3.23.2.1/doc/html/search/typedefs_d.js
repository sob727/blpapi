var searchData=
[
  ['value_5ftype',['value_type',['../classBloombergLP_1_1blpapi_1_1Event_1_1iterator.html#a19eb719867c5d0a62833a055be9e0938',1,'BloombergLP::blpapi::Event::iterator::value_type()'],['../classBloombergLP_1_1blpapi_1_1Bytes.html#acd77781b83256555c54fe8b83be4d624',1,'BloombergLP::blpapi::Bytes::value_type()']]]
];
