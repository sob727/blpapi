var searchData=
[
  ['reference',['reference',['../classBloombergLP_1_1blpapi_1_1Event_1_1iterator.html#ab9ef489a4ad498771bbb3154067afca8',1,'BloombergLP::blpapi::Event::iterator::reference()'],['../classBloombergLP_1_1blpapi_1_1Bytes.html#a72813434a61cfa01ac219f69014fbd12',1,'BloombergLP::blpapi::Bytes::reference()']]],
  ['reverse_5fiterator',['reverse_iterator',['../classBloombergLP_1_1blpapi_1_1Bytes.html#a92b881db836646f4039adcbb73c8595f',1,'BloombergLP::blpapi::Bytes']]]
];
