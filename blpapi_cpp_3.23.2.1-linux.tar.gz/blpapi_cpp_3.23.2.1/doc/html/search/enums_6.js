var searchData=
[
  ['type',['Type',['../structBloombergLP_1_1blpapi_1_1Logging_1_1Severity.html#a1d1cfd8ffb84e947f82999c682b666a7',1,'BloombergLP::blpapi::Logging::Severity::Type()'],['../structBloombergLP_1_1blpapi_1_1Message_1_1RecapType.html#a1d1cfd8ffb84e947f82999c682b666a7',1,'BloombergLP::blpapi::Message::RecapType::Type()']]]
];
