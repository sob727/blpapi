var searchData=
[
  ['unbounded',['UNBOUNDED',['../classBloombergLP_1_1blpapi_1_1SchemaElementDefinition.html#adf764cbdea00d65edcd07bb9953ad2b7a6c65123d1b5b01632a477661055b01ef',1,'BloombergLP::blpapi::SchemaElementDefinition']]],
  ['unknown',['UNKNOWN',['../classBloombergLP_1_1blpapi_1_1Event.html#a2628ea8d12e8b2563c32f05dc7fff6faa6ce26a62afab55d7606ad4e92428b30c',1,'BloombergLP::blpapi::Event']]],
  ['unresolved',['UNRESOLVED',['../classBloombergLP_1_1blpapi_1_1ResolutionList.html#a67a0db04d321a74b7e7fcfd3f1a3f70badd34e323cbfc10e56499d492dd2c3a66',1,'BloombergLP::blpapi::ResolutionList']]],
  ['unset_5fvalue',['UNSET_VALUE',['../classBloombergLP_1_1blpapi_1_1CorrelationId.html#ad9971b6ef33e02ba2c75d19c1d2518a1a8ce57869ee04cf783d86b39154e670be',1,'BloombergLP::blpapi::CorrelationId']]],
  ['unsubscribed',['UNSUBSCRIBED',['../classBloombergLP_1_1blpapi_1_1Session.html#a141815705f02d1c10701317803aa6031a74a51cb85a77f7a1752500134658ebd3',1,'BloombergLP::blpapi::Session']]]
];
