var searchData=
[
  ['float32',['Float32',['../namespaceBloombergLP_1_1blpapi.html#a77d1ede4c150b45849e05c667edb066a',1,'BloombergLP::blpapi']]],
  ['float64',['Float64',['../namespaceBloombergLP_1_1blpapi.html#a5e08e5356d105282b06e99b1cc76179a',1,'BloombergLP::blpapi']]]
];
