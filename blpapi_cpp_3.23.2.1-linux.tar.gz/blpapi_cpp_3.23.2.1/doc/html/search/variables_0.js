var searchData=
[
  ['authorizationfailure',['AuthorizationFailure',['../structBloombergLP_1_1blpapi_1_1Names.html#a5cc7c2dd1e2e253cc5b4853ff5aef83f',1,'BloombergLP::blpapi::Names']]],
  ['authorizationrevoked',['AuthorizationRevoked',['../structBloombergLP_1_1blpapi_1_1Names.html#afd23ba69d00fd05545231f3a4ca66208',1,'BloombergLP::blpapi::Names']]],
  ['authorizationsuccess',['AuthorizationSuccess',['../structBloombergLP_1_1blpapi_1_1Names.html#adf070ba20b64be3f8f98d5302b58c3b9',1,'BloombergLP::blpapi::Names']]]
];
