var searchData=
[
  ['nonbps',['NONBPS',['../classBloombergLP_1_1blpapi_1_1Identity.html#a476531b8b779ebb4a8672ef5b44a4de2a15fc903deff4bc54a6ae9ea2479ea1ba',1,'BloombergLP::blpapi::Identity']]],
  ['not_5fcreated',['NOT_CREATED',['../classBloombergLP_1_1blpapi_1_1TopicList.html#a67a0db04d321a74b7e7fcfd3f1a3f70bae09255dfad832f9757086a36ebfcc909',1,'BloombergLP::blpapi::TopicList']]]
];
