var structBloombergLP_1_1blpapi_1_1Logging =
[
    [ "Severity", "structBloombergLP_1_1blpapi_1_1Logging_1_1Severity.html", "structBloombergLP_1_1blpapi_1_1Logging_1_1Severity" ],
    [ "logTestMessage", "structBloombergLP_1_1blpapi_1_1Logging.html#af69f3b4a2c80acdee48d5420a718cb1e", null ]
];