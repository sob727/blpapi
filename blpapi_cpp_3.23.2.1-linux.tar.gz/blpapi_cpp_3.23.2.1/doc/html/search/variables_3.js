var searchData=
[
  ['exceptionclass',['exceptionClass',['../group__blpapi__exception.html#gafe114d20f411d14826756e412e3ecf6b',1,'blpapi_ErrorInfo']]]
];
