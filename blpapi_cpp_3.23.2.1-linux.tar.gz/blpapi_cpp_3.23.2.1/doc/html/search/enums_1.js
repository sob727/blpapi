var searchData=
[
  ['clientmode',['ClientMode',['../classBloombergLP_1_1blpapi_1_1SessionOptions.html#a8f5e4eb36ccab24faf886a87736953d0',1,'BloombergLP::blpapi::SessionOptions']]],
  ['code',['Code',['../structBloombergLP_1_1blpapi_1_1SubscriptionPreprocessError.html#af31477bc48f67856bedb0fa8e5b5281d',1,'BloombergLP::blpapi::SubscriptionPreprocessError']]]
];
