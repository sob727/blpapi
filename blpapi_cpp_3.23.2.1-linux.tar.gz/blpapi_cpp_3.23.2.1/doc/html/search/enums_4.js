var searchData=
[
  ['registrationparts',['RegistrationParts',['../classBloombergLP_1_1blpapi_1_1ServiceRegistrationOptions.html#aba5280e44c834fccbd731287c6c938fb',1,'BloombergLP::blpapi::ServiceRegistrationOptions']]],
  ['remote',['Remote',['../classBloombergLP_1_1blpapi_1_1ZfpUtil.html#a0a4cb986ff60692b75e70e6e987db81c',1,'BloombergLP::blpapi::ZfpUtil']]],
  ['resolvemode',['ResolveMode',['../classBloombergLP_1_1blpapi_1_1ProviderSession.html#a885aee02050e647ce0672264d2b2d858',1,'BloombergLP::blpapi::ProviderSession']]]
];
