var structBloombergLP_1_1blpapi_1_1Logging_1_1Severity =
[
    [ "Type", "structBloombergLP_1_1blpapi_1_1Logging_1_1Severity.html#a1d1cfd8ffb84e947f82999c682b666a7", [
      [ "e_off", "structBloombergLP_1_1blpapi_1_1Logging_1_1Severity.html#a1d1cfd8ffb84e947f82999c682b666a7afb9d11ef9b828174e8e5df5bbb9833fe", null ],
      [ "e_fatal", "structBloombergLP_1_1blpapi_1_1Logging_1_1Severity.html#a1d1cfd8ffb84e947f82999c682b666a7aa7f7fcccdcdcab03b084fb653b6ce9eb", null ],
      [ "e_error", "structBloombergLP_1_1blpapi_1_1Logging_1_1Severity.html#a1d1cfd8ffb84e947f82999c682b666a7a7c9f15a6690761dca8c39a7b834623fd", null ],
      [ "e_warn", "structBloombergLP_1_1blpapi_1_1Logging_1_1Severity.html#a1d1cfd8ffb84e947f82999c682b666a7a8cee4adf64c27cde4306130d30091e8e", null ],
      [ "e_info", "structBloombergLP_1_1blpapi_1_1Logging_1_1Severity.html#a1d1cfd8ffb84e947f82999c682b666a7a7c4df249925c94135bbdff7b481da401", null ],
      [ "e_debug", "structBloombergLP_1_1blpapi_1_1Logging_1_1Severity.html#a1d1cfd8ffb84e947f82999c682b666a7a88dfc4a0234c400d9edabd60456c5755", null ],
      [ "e_trace", "structBloombergLP_1_1blpapi_1_1Logging_1_1Severity.html#a1d1cfd8ffb84e947f82999c682b666a7a3e97b31c72e75882868ac8b69931a5fa", null ]
    ] ]
];